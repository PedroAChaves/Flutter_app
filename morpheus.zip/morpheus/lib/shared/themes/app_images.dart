class AppImages {
  static const logoMorpheus = "images/logo.png";
  static const text = "images/text.png";
  static const backgroundLogin = "images/BackgroundLogin.png";
}
